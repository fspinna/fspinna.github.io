# Annotation guidelines: domain of a person

Each row of `gold_annotations.csv` is the first paragraph of the English Wikipedia
biography of a person from Tuscany. Write in the `label` column the **domain the person
is mainly known for**, using exactly one of the nine labels below.

Read only the paragraph. Do not look the person up: the model will only see this text,
and the labels must describe the same text.

## Labels

| Label | Includes |
|---|---|
| `visual arts` | painters, sculptors, architects, engravers, illustrators, photographers, designers (including fashion), goldsmiths |
| `literature` | writers, poets, novelists, playwrights, translators, journalists, librettists, and scholars of the humanities: historians, philosophers, philologists, art historians, critics |
| `music` | composers, musicians, singers (including opera), conductors |
| `film and stage` | actors and actresses, film and theatre directors, screenwriters, dancers, comedians, television presenters |
| `science` | natural and formal sciences, medicine, engineering, economics, archaeology, inventors |
| `politics` | politicians, mayors, diplomats, ministers, rulers and heads of state, jurists and lawyers |
| `religion` | popes, cardinals, bishops, priests, monks, nuns, saints, theologians |
| `sport` | athletes of any sport, including coaches, managers and referees |
| `other` | anyone else: business, military, nobility without a political role, crime, exploration, ... |

## Decision rules

1. **Several occupations**: choose the one the paragraph presents as the main one. When the
   paragraph lists them without a ranking ("painter, poet and priest"), choose the **first**.
2. **Religious people with another career**: a friar known for painting is `visual arts`; a
   bishop known as a bishop is `religion`.
3. **Academics**: label by discipline (a professor of physics is `science`, of history is
   `literature`).
4. **Rulers and nobility**: `politics` if the paragraph describes a political role (duke,
   lord of a city, head of state); `other` otherwise.
5. **Unsure**: still choose the most likely label, and write a short reason in the `note`
   column. The notes are used to revise these guidelines.

## Practicalities

- Do not change the `title` and `text` columns, and do not reorder or delete rows.
- Save as CSV with UTF-8 encoding (the file contains accented names).
- Labels must be spelled exactly as in the table, lowercase.
