# People from Tuscany: first paragraphs of Wikipedia biographies

- **Source**: English Wikipedia, collected on 2026-10-25 through the MediaWiki API, starting from the
  categories *People from Florence, Pisa, Siena, Lucca, Livorno, Arezzo, Pistoia, Prato, Grosseto, Carrara*.
- **Content** (`people.jsonl`): 2,567 biographies; for each, the title, URL, city, first paragraph of the
  introduction, and only the categories used by the labeling rules (the others were removed).
- **Labels** (`gold_annotations.csv`, `.xlsx`): 200 paragraphs annotated by hand, following
  `annotation_guidelines.md`.
- **License**: the text is from Wikipedia and is licensed under
  [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/); the URL of each record credits its page.
  This dataset, as a derived work, is shared under the same license.
- **Personal data**: the records describe real people, many of them alive. They are provided **for teaching in
  the Text Analytics course (University of Pisa)** only. Do not republish them or combine them with other data
  about the same people.
